#!/bin/bash
# ═══════════════════════════════════════════════════════════════
# WINDI Integration Deploy v1.1 — a4Desk BABEL → War Room
# Created: 05 Feb 2026 (v1.1 — with dedicated log + correlation)
# "AI processes. Human decides. WINDI guarantees."
# ═══════════════════════════════════════════════════════════════

set -e

BABEL_DIR="/opt/windi/a4desk-editor"
BABEL_FILE="$BABEL_DIR/a4desk_tiptap_babel.py"
BRIDGE_FILE="$BABEL_DIR/governance_bridge.py"
BACKUP_DIR="/opt/windi/backups/pre_bridge_$(date +%Y%m%d_%H%M%S)"
LOG_DIR="/var/log/windi"
PATCH_MARKER="# ─── GOVERNANCE BRIDGE"

echo "═══════════════════════════════════════════════════════════"
echo "  WINDI Integration Deploy v1.1"
echo "  $(date -u '+%Y-%m-%d %H:%M:%S UTC')"
echo "═══════════════════════════════════════════════════════════"
echo ""

# ─── STEP 1: Verify pre-existing backup ─────────────────────
echo "[1/8] Verifying backup..."
LATEST_BACKUP=$(ls -td /opt/windi/backups/pre_integration_* 2>/dev/null | head -1)
if [ -z "$LATEST_BACKUP" ]; then
    echo "  ✗ No pre-integration backup found! Run backup first."
    exit 1
fi
echo "  ✓ Found: $LATEST_BACKUP ($(du -sh "$LATEST_BACKUP" | cut -f1))"

# ─── STEP 2: Deploy-specific backup ─────────────────────────
echo "[2/8] Creating deploy backup..."
mkdir -p "$BACKUP_DIR"
cp "$BABEL_FILE" "$BACKUP_DIR/a4desk_tiptap_babel.py.bak"
echo "  ✓ Saved to $BACKUP_DIR"

# ─── STEP 3: Check if already patched ───────────────────────
echo "[3/8] Checking patch status..."
if grep -q "$PATCH_MARKER" "$BABEL_FILE"; then
    echo "  ⚠ Already patched! Run rollback first: bash /tmp/rollback_bridge.sh"
    exit 1
fi
echo "  ✓ Clean state"

# ─── STEP 4: Create log directory ────────────────────────────
echo "[4/8] Creating log directory..."
if [ -d "$LOG_DIR" ]; then
    echo "  ✓ $LOG_DIR exists"
else
    sudo mkdir -p "$LOG_DIR" 2>/dev/null || mkdir -p "$LOG_DIR"
    echo "  ✓ Created $LOG_DIR"
fi
# Ensure windi user can write
sudo chown -R windi:windi "$LOG_DIR" 2>/dev/null || true
chmod 755 "$LOG_DIR"
echo "  ✓ Permissions set"

# ─── STEP 5: Install bridge module ──────────────────────────
echo "[5/8] Installing governance_bridge.py (v1.1)..."
cp /tmp/governance_bridge.py "$BRIDGE_FILE"
chmod 644 "$BRIDGE_FILE"
echo "  ✓ Bridge installed"

# ─── STEP 6: Test Governance API ─────────────────────────────
echo "[6/8] Testing Governance API..."
API_STATUS=$(curl -s -o /dev/null -w "%{http_code}" http://127.0.0.1:8080/api/status 2>/dev/null || echo "000")
if [ "$API_STATUS" = "200" ]; then
    echo "  ✓ API responding (HTTP 200)"
else
    echo "  ⚠ API not responding (HTTP $API_STATUS) — bridge will degrade gracefully"
fi

# ─── STEP 7: Patch BABEL finalize ────────────────────────────
echo "[7/8] Patching BABEL finalize_document()..."

PATCH_LINE=$(grep -n 'return jsonify({"id": doc_id, "status": "finalized", "receipt": receipt})' "$BABEL_FILE" | head -1 | cut -d: -f1)

if [ -z "$PATCH_LINE" ]; then
    echo "  ✗ Could not find finalize return! Aborting."
    exit 1
fi

echo "  Found return at line $PATCH_LINE"

sed -i "${PATCH_LINE}i\\
\\
    # ─── GOVERNANCE BRIDGE: Submit to War Room (v1.1) ──────────\\
    try:\\
        from governance_bridge import submit_to_governance\\
        bridge_result = submit_to_governance(\\
            doc_id=doc_id,\\
            content_text=row[\"content\"],\\
            language=row[\"language\"],\\
            author_data=author_data,\\
            witness_data=witness_data,\\
            receipt=receipt,\\
            domain_tag=domain_tag,\\
        )\\
        if bridge_result:\\
            _corr = bridge_result.get('bridge_correlation_id', '?')\\
            _sub = bridge_result.get('submission_id', bridge_result.get('id', '?'))\\
            print(f\"[BRIDGE] Doc {doc_id} → War Room: submission={_sub} corr={_corr}\")\\
        else:\\
            print(f\"[BRIDGE] Doc {doc_id} → War Room: API offline (graceful skip)\")\\
    except Exception as bridge_err:\\
        print(f\"[BRIDGE] Non-critical error for {doc_id}: {bridge_err}\")\\
    # ─── END GOVERNANCE BRIDGE ─────────────────────────────────" "$BABEL_FILE"

if grep -q "$PATCH_MARKER" "$BABEL_FILE"; then
    echo "  ✓ Patch applied"
else
    echo "  ✗ Patch failed! Restoring..."
    cp "$BACKUP_DIR/a4desk_tiptap_babel.py.bak" "$BABEL_FILE"
    exit 1
fi

# ─── STEP 8: Syntax check ───────────────────────────────────
echo "[8/8] Python syntax check..."
cd "$BABEL_DIR"
python3 -c "import py_compile; py_compile.compile('$BABEL_FILE', doraise=True)" 2>&1
if [ $? -eq 0 ]; then
    echo "  ✓ Syntax OK"
else
    echo "  ✗ Syntax error! Restoring..."
    cp "$BACKUP_DIR/a4desk_tiptap_babel.py.bak" "$BABEL_FILE"
    exit 1
fi

echo ""
echo "═══════════════════════════════════════════════════════════"
echo "  ✅ INTEGRATION v1.1 INSTALLED"
echo ""
echo "  Bridge:  $BRIDGE_FILE (v1.1.0)"
echo "  Log:     /var/log/windi/governance_bridge.log"
echo "  Backup:  $BACKUP_DIR"
echo ""
echo "  Features:"
echo "    ✓ Dedicated governance log (evidence trail)"
echo "    ✓ Correlation IDs (GBR-BRIDGE-YYYYMMDD-XXXX)"
echo "    ✓ Throttle 200ms (flood protection)"
echo "    ✓ Graceful degradation (API down = skip)"
echo ""
echo "  ⚠ RESTART BABEL TO ACTIVATE:"
echo ""
echo "    pkill -f a4desk_tiptap_babel"
echo "    cd $BABEL_DIR"
echo "    source /etc/windi/secrets.env"
echo "    nohup python3 a4desk_tiptap_babel.py > /tmp/a4desk.log 2>&1 &"
echo ""
echo "  VERIFY:"
echo "    bash /tmp/test_bridge.sh"
echo "    tail -f /var/log/windi/governance_bridge.log"
echo ""
echo "  ROLLBACK:"
echo "    bash /tmp/rollback_bridge.sh"
echo "═══════════════════════════════════════════════════════════"

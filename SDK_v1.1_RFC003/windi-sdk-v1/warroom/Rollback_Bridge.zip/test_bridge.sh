#!/bin/bash
# ═══════════════════════════════════════════════════════════════
# WINDI Integration Test Suite v1.1
# ═══════════════════════════════════════════════════════════════

echo "═══════════════════════════════════════════════════════════"
echo "  WINDI Integration Test Suite v1.1"
echo "  $(date -u '+%Y-%m-%d %H:%M:%S UTC')"
echo "═══════════════════════════════════════════════════════════"
echo ""

PASS=0; FAIL=0
ok() { echo "  ✓ PASS: $1"; PASS=$((PASS+1)); }
fail() { echo "  ✗ FAIL: $1"; FAIL=$((FAIL+1)); }

# ─── Test 1: BABEL ─────────────────────────────────────────
echo "[1/10] BABEL Health..."
H=$(curl -s -o /dev/null -w "%{http_code}" http://127.0.0.1:8085/api/health 2>/dev/null)
[ "$H" = "200" ] && ok "BABEL HTTP 200" || fail "BABEL HTTP $H"

# ─── Test 2: Governance API ─────────────────────────────────
echo "[2/10] Governance API..."
H=$(curl -s -o /dev/null -w "%{http_code}" http://127.0.0.1:8080/api/status 2>/dev/null)
[ "$H" = "200" ] && ok "Governance API HTTP 200" || fail "Governance API HTTP $H"

# ─── Test 3: War Room ───────────────────────────────────────
echo "[3/10] War Room..."
H=$(curl -s -o /dev/null -w "%{http_code}" http://127.0.0.1:8090/war-room/ 2>/dev/null)
[ "$H" = "200" ] && ok "War Room HTTP 200" || fail "War Room HTTP $H"

# ─── Test 4: Bridge import ───────────────────────────────────
echo "[4/10] Bridge module..."
cd /opt/windi/a4desk-editor
R=$(python3 -c "from governance_bridge import health_check; h=health_check(); print(h['status'], h.get('bridge_version','?'))" 2>&1)
echo "$R" | grep -q "connected" && ok "Bridge imports + connects ($R)" || fail "Bridge: $R"

# ─── Test 5: Patch in BABEL ──────────────────────────────────
echo "[5/10] BABEL patch..."
grep -q "GOVERNANCE BRIDGE" /opt/windi/a4desk-editor/a4desk_tiptap_babel.py && ok "Patch present" || fail "Patch NOT found"

# ─── Test 6: Log directory ───────────────────────────────────
echo "[6/10] Log directory..."
[ -d "/var/log/windi" ] && ok "/var/log/windi exists" || fail "/var/log/windi missing"
touch /var/log/windi/.test_write 2>/dev/null && rm /var/log/windi/.test_write && ok "Writable" || fail "Not writable"

# ─── Test 7: Briefing API ────────────────────────────────────
echo "[7/10] Briefing API..."
B=$(curl -s http://127.0.0.1:8090/api/briefing 2>/dev/null)
echo "$B" | python3 -c "import sys,json; d=json.load(sys.stdin); assert d.get('success')==True" 2>/dev/null
[ $? -eq 0 ] && ok "Briefing returns valid data" || fail "Briefing invalid"

# ─── Test 8: Submissions endpoint ────────────────────────────
echo "[8/10] Submissions..."
S=$(curl -s http://127.0.0.1:8080/api/submissions 2>/dev/null)
SC=$(echo "$S" | python3 -c "import sys,json; print(json.load(sys.stdin).get('total',0))" 2>/dev/null)
[ -n "$SC" ] && ok "Submissions: $SC total" || fail "Submissions failed"

# ─── Test 9: Bridge dry submit + correlation ID ──────────────
echo "[9/10] Bridge submit + correlation ID..."
cd /opt/windi/a4desk-editor
DRY=$(python3 -c "
from governance_bridge import submit_to_governance
r = submit_to_governance(
    doc_id='TEST-BRIDGE-V11-001',
    content_text='Integration test v1.1 — correlation check',
    language='en',
    author_data={'name': 'Test Author', 'department': 'QA'},
    witness_data={'name': 'Test Prüfer', 'role': 'Prüfer'},
    receipt={'receipt_id': 'TEST-RECEIPT-V11'},
    domain_tag='operational',
    governance_level='LOW',
)
if r:
    corr = r.get('bridge_correlation_id', 'MISSING')
    sid = r.get('submission_id', r.get('id', '?'))
    print(f'OK corr={corr} sub={sid}')
else:
    print('OFFLINE')
" 2>&1)

if echo "$DRY" | grep -q "OK corr=GBR-BRIDGE"; then
    ok "Submit + correlation: $DRY"
elif echo "$DRY" | grep -q "OFFLINE"; then
    fail "API offline"
else
    fail "Error: $DRY"
fi

# ─── Test 10: Log file written ────────────────────────────────
echo "[10/10] Bridge log..."
sleep 1
if [ -f "/var/log/windi/governance_bridge.log" ]; then
    LINES=$(wc -l < /var/log/windi/governance_bridge.log)
    LAST=$(tail -1 /var/log/windi/governance_bridge.log)
    ok "Log exists ($LINES lines)"
    echo "       Last: $LAST"
else
    fail "Log file not created"
fi

echo ""
echo "═══════════════════════════════════════════════════════════"
echo "  Results: $PASS passed, $FAIL failed (of 10)"
if [ "$FAIL" -eq 0 ]; then
    echo "  🐉 ALL TESTS PASSED — Integration v1.1 is LIVE"
else
    echo "  ⚠ $FAIL test(s) failed — review above"
fi
echo ""
echo "  Bridge log:  tail -f /var/log/windi/governance_bridge.log"
echo "  Bridge stats: cd /opt/windi/a4desk-editor && python3 -c \"from governance_bridge import get_submission_stats; print(get_submission_stats())\""
echo "═══════════════════════════════════════════════════════════"

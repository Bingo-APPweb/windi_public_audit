# WINDI Governance Bridge v1.1 — Integration Package
## a4Desk BABEL → War Room via Governance API

**Created:** 05 Feb 2026
**Version:** 1.1.0 (Architect Dragon review incorporated)
**Backup:** `/opt/windi/backups/pre_integration_20260205_1518`

---

## Architecture

```
BABEL :8085                Governance API :8080         War Room :8090
finalize_document()  POST  /api/generate                /api/briefing (30s poll)
  │                    │                                   │
  │ correlation_id     │ submission created                │ Decision Card
  │ GBR-BRIDGE-xxx     │ SGE scored                        │ shows origin +
  │                    │ Ledger sealed                     │ correlation ID
  ▼                    ▼                                   ▼
  receipt              Virtue Receipt                      APPROVE / REJECT
```

## v1.1 Improvements (Architect Review)

| Feature | Purpose |
|---------|---------|
| Dedicated log | `/var/log/windi/governance_bridge.log` — governance evidence trail |
| Correlation ID | `GBR-BRIDGE-YYYYMMDD-XXXX` — chain of custody from doc to decision |
| Throttle 200ms | Flood protection — governance must be stable, not nervous |
| Failed attempt logging | Proves governance INTENT even when infrastructure fails |
| `get_failed_submissions()` | Audit query for failed attempts |
| `get_submission_stats()` | Monitoring: attempts/success/failed/throttled |

## Log Format (Audit Evidence)

```
[2026-02-05 15:30:12] [BRIDGE] [INFO] SUBMIT_ATTEMPT doc_id=DOC-001 corr=GBR-BRIDGE-20260205-0001 level=HIGH domain=institutional receipt=WR-001 hash=a1b2c3d4e5f6
[2026-02-05 15:30:12] [BRIDGE] [INFO] SUBMIT_SUCCESS doc_id=DOC-001 corr=GBR-BRIDGE-20260205-0001 submission=SUB-001 level=HIGH elapsed=45ms
[2026-02-05 15:30:15] [BRIDGE] [ERROR] SUBMIT_FAILED doc_id=DOC-002 corr=GBR-BRIDGE-20260205-0002 reason=api_unreachable error="timeout" elapsed=10003ms
```

## Deploy

**PowerShell:**
```powershell
cd "DOWNLOAD_FOLDER"
scp governance_bridge.py windi@87.106.29.233:/tmp/
scp deploy_bridge.sh windi@87.106.29.233:/tmp/
scp rollback_bridge.sh windi@87.106.29.233:/tmp/
scp test_bridge.sh windi@87.106.29.233:/tmp/
```

**Strato SSH:**
```bash
bash /tmp/deploy_bridge.sh

pkill -f a4desk_tiptap_babel
cd /opt/windi/a4desk-editor
source /etc/windi/secrets.env
nohup python3 a4desk_tiptap_babel.py > /tmp/a4desk.log 2>&1 &

bash /tmp/test_bridge.sh
```

## Rollback (10 seconds)
```bash
bash /tmp/rollback_bridge.sh
pkill -f a4desk_tiptap_babel
cd /opt/windi/a4desk-editor && source /etc/windi/secrets.env
nohup python3 a4desk_tiptap_babel.py > /tmp/a4desk.log 2>&1 &
```

Note: Rollback preserves the bridge log (evidence trail).

---

*"AI processes. Human decides. WINDI guarantees."*

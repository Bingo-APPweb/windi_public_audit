#!/bin/bash
# ═══════════════════════════════════════════════════════════════
# WINDI Integration Rollback v1.1
# ═══════════════════════════════════════════════════════════════

BABEL_DIR="/opt/windi/a4desk-editor"
BABEL_FILE="$BABEL_DIR/a4desk_tiptap_babel.py"
BRIDGE_FILE="$BABEL_DIR/governance_bridge.py"

echo "═══════════════════════════════════════════════════════════"
echo "  WINDI Integration Rollback"
echo "  $(date -u '+%Y-%m-%d %H:%M:%S UTC')"
echo "═══════════════════════════════════════════════════════════"

# Find most recent deploy backup
LATEST=$(ls -td /opt/windi/backups/pre_bridge_*/a4desk_tiptap_babel.py.bak 2>/dev/null | head -1)

if [ -z "$LATEST" ]; then
    # Fallback to pre-integration backup
    LATEST=$(ls -td /opt/windi/backups/pre_integration_*/a4desk-editor/a4desk_tiptap_babel.py 2>/dev/null | head -1)
fi

if [ -z "$LATEST" ]; then
    echo "  ✗ No backup found!"
    exit 1
fi

echo "[1/4] Backup: $LATEST"

echo "[2/4] Restoring BABEL..."
cp "$LATEST" "$BABEL_FILE"
echo "  ✓ Restored"

echo "[3/4] Removing bridge..."
[ -f "$BRIDGE_FILE" ] && rm "$BRIDGE_FILE" && echo "  ✓ Removed" || echo "  - Not found"

echo "[4/4] Verifying..."
grep -q "GOVERNANCE BRIDGE" "$BABEL_FILE" && echo "  ✗ Traces remain!" || echo "  ✓ Clean"

echo ""
echo "  Note: Bridge log preserved at /var/log/windi/governance_bridge.log"
echo "        (evidence trail — do not delete)"
echo ""
echo "  Restart: pkill -f a4desk_tiptap_babel && cd $BABEL_DIR && source /etc/windi/secrets.env && nohup python3 a4desk_tiptap_babel.py > /tmp/a4desk.log 2>&1 &"
echo "═══════════════════════════════════════════════════════════"
